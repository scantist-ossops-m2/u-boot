/*
 * (C) Copyright 2007
 *
 * Author : Carsten Schneider, mycable GmbH
 *          <cs@mycable.de>
 *
 * SPDX-License-Identifier:	GPL-2.0+
 */
#ifndef __ASM_ARCH_HARDWARE_H
#define __ASM_ARCH_HARDWARE_H

#include <asm/sizes.h>
#include <asm/arch/mb86r0x.h>

#endif
